## 1.1.3

* Added node 0.7.x support

## 1.1.2

* Fix compiling on Darwin and Windows. Thanks to Vinay Pulim https://github.com/milewise

## 1.1.1

* Minor change to package to support 0.4 version

## 1.1.0

* Port to 0.5.7 Node version

## 1.0.2

* Fixed MAIL log facility
* Removed leaking Syslog underlying function object from top-level library.

## 1.0.1

* Added setMask (Jeremy Childs)

## 1.0.0

* Initial release version
