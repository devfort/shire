##1.1.7

* fix compatibility to feature node 0.9.x versions

##1.1.6

* remove compilation flags from binding.gyp that cause build failure with older gcc versions
* cleanups

##1.1.5

* remove old nodejs version support prior to 0.8.0
* fix building

## 1.1.4

* Cleaned all opened and not closed ScopeHandlers
* Added new node-gyp build file. Next release will not support node-waf and node version < 0.8.x

## 1.1.3

* Added node 0.7.x support

## 1.1.2

* Fix compiling on Darwin and Windows. Thanks to Vinay Pulim https://github.com/milewise

## 1.1.1

* Minor change to package to support 0.4 version

## 1.1.0

* Port to 0.5.7 Node version

## 1.0.2

* Fixed MAIL log facility
* Removed leaking Syslog underlying function object from top-level library.

## 1.0.1

* Added setMask (Jeremy Childs)

## 1.0.0

* Initial release version
